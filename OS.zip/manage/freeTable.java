package manage;
public class freeTable {
    public int address;//空闲分区起始地址
    public int length;//空闲分区长度
    public freeTable() {
    }
}