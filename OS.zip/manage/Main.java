package manage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Main {

    public static final int diskSize = 1024*1024*64; //磁盘空间大小
    public static File disk = new File("disk");
    public static Total total;
    public static Catalog nowcpoint;
    public static FCB openfile;
    public static void main(String[] args) throws IOException {
        boolean running=true;
        total = new Total();
        nowcpoint = total.boot.son[0];
        read();   
        String part1;
        String part2;

        while(running){
            new menu();
            menu.main(args);
            Scanner scanner = new Scanner(System.in);
                int instruction ;
                instruction = scanner.nextInt();              
                switch(instruction){
                        case 0://用户未选择
                            System.out.println("用户未选择命令");
                            System.out.println("请选择一条命令");
                            break;
                        case 1://help   提示用户命令的用法
                            Instruction.help();
                            break;
                        case 2://dir  列给定路径的文件目录列给定路径的文件目录
                            System.out.println("输入路径：");
                            part1 = scanner.next();
                            Instruction.dir(part1);
                            break;
                        case 3://treedir
                            System.out.println("输入目录名称：");
                            part1 = scanner.next();
                            Instruction.treedir(part1);
                            break;
                        case 4://mkdir  参数1：创建文件夹的位置     参数2：新建文件夹名称
                            System.out.println("输入目录位置与目录名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.mkdir(part1 , part2);
                            break;
                        case 5://deldir
                            System.out.println("输入目录位置与目录名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.deldir(part1 , part2);
                            break;
                        case 6://xcopydir
                            System.out.println("输入源目录位置目录名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.xcopydir(part1,part2);
                            break;
                        case 7://cd
                            System.out.println("输入路径：");
                            part1 = scanner.next();
                            Instruction.cd(part1);
                            break;
                        case 8://create    创建指定路径下给定文件名的文件
                            System.out.println("输入文件位置与文件名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.create(part1 , part2);
                            break;
                        case 9://open    打开指定路径下给定文件名的文件，供下面的read/write操作调用
                            System.out.println("输入文件位置与文件名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.open(part1,part2);
                            break;
                        case 10://close   关闭指定路径下给定文件名的文件，供下面的read/write操作调用
                            Instruction.close();
                            break;
                        case 11://read
                            Instruction.read();
                            break;
                        case 12://write
                            Instruction.write();
                            break;
                        case 13://copy  将给定文件名的文件复制到给定路径下
                            System.out.println("输入源文件位置与名称：");
                            part1 = scanner.next();
                            part2 = scanner.next();
                            Instruction.copy(part1 , part2);
                            break;
                        case 14://end   退出循环，结束程序
                            running = false;
                            System.out.println("程序结束");
                            break;
                        default:
                            System.out.println("命令错误");
                            break;
      }
            }
}

    //读取磁盘文件函数
    public static void read() throws IOException {
        if(!disk.exists()){//磁盘文件不存在
            disk.createNewFile();
            nowcpoint = total.boot.son[0];//当前工作目录为/root目录
            //将现有信息写入磁盘，其实只写入total对象即可
            write();
            return;
        }

        //能执行到这里，说明disk文件已存在，直接读取
        BufferedReader br = new BufferedReader(new FileReader("disk"));


        //读取空闲管理快
        String temp = br.readLine();
        String[] str = temp.split("\\s+");
        total.freetable.address = Integer.parseInt(str[0]);
        total.freetable.length = Integer.parseInt(str[1]);

        //读取文件数量
        temp = br.readLine();
        str = temp.split("\\s+");
        total.fileNumber = Integer.parseInt(str[0]);
        temp = br.readLine();
        for(int i = 0;i < temp.length();i++){
            if(temp.charAt(i) == '$')
                total.buffer[i] = '\n';
            else
                total.buffer[i] = temp.charAt(i);
        }
        //递归读取boot目录信息
        readDir(br,total.boot);
        br.close();

    }
    public static void write() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("disk"));
        bw.write(total.freetable.address + "\t" + total.freetable.length + "\n");
        bw.write(total.fileNumber + "\n");
        StringBuffer content = new StringBuffer();
        for(int i = 0;i < total.freetable.address;i++){
            if(total.buffer[i] == '\n')
                content.append('$');
            else
                content.append(total.buffer[i]);
        }
        bw.write(content + "\n");
        writeDir(bw , total.boot);


        bw.flush();
        bw.close();
    }

    public static void writeDir(BufferedWriter bw , Catalog g) throws IOException {
        bw.write(g.name + "\t" + g.sonnum + "\t" + g.inodenum + "\n");
        for(int i = 0;i < g.inodenum;i++){
            bw.write(g.inode[i].name + "\t" + g.inode[i].lastime  + "\t" + g.inode[i].size + "\t"  +g.inode[i].text+ "\n");
        }

        for(int i = 0;i < g.sonnum;i++){
            Catalog m = g.son[i];
            writeDir(bw,m);
        }
    }

    public static void readDir(BufferedReader br , Catalog g) throws IOException {
        String temp = br.readLine();
        String[] str = temp.split("\\s+");
        g.name = str[0];
        g.sonnum = Integer.parseInt(str[1]);
        g.inodenum = Integer.parseInt(str[2]);
 
        for(int i = 0;i < g.inodenum;i++){
            temp = br.readLine();
            str = temp.split("\\s+");
            g.inode[i] = new FCB();
            g.inode[i].name = str[0];
            g.inode[i].lastime = str[1];
            g.inode[i].size = Integer.parseInt(str[2]);
            g.inode[i].text = str[3];
        }



        for(int i = 0;i < g.sonnum;i++){
            g.son[i] = new Catalog();
            readDir(br,g.son[i]);
        }

    } 
    
}

