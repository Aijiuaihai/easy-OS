package manage;
public class Catalog {
    public String name;//目录名称
    public Catalog[] son = new Catalog[100];//该目录下的子目录
    public FCB[] inode = new FCB[100];//该目录下的文件
    public int sonnum;//子目录数量
    public int inodenum;//子文件数量
    public int size;//使用文件类来表示硬盘，以实现分区，无大小为目录，有大小则为一个分区
    public freeTable freetable = new freeTable();//空闲表
    public Catalog() {//如果不定义为磁盘，则初始化为目录
        this.size=0;
        this.freetable.address = 0;
        this.freetable.length = 0;
    }
}