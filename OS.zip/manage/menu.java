package manage;
public class menu {
    public static void main(String[] args) {
        // 定义一个字符串数组存储内容
        String[] content = {"1.调出帮助目录", "2.列出该路径目录", "3.显示全部目录", "4.创建目录", "5.删除目录", "6.复制目录", "7.切换目录", "8.创建文件", "9.打开文件", "10.关闭文件", "11.读文件", "12.写文件", "13.复制文件", "14.退出系统"};
        // 使用for循环遍历数组并输出
        for (int i = 0; i < content.length; i++) {
            System.out.println(content[i]);
        }
    }
}
