package manage;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Instruction {
    public static Catalog deleteconfirm = null;
    public static String deleteconfirm2;

    public Instruction() {
    }

    public static void help() {
        System.out.print("dir----------列出给定目录的文件目录。该命令仅列出指定目录下的子目录和子文件，对于子目录下的内容将不列出。\n");
        System.out.print("             该命令需要0个或1个参数。\n");
        System.out.print("treedir------循环列出给定目录及其子子孙孙的目录结构，以树形结构给出。\n");
        System.out.print("             该命令需要0个或1个参数。\n");
        System.out.print("mkdir--------创建给定名称的目录。\n");
        System.out.print("             该命令需要1个或2个参数。\n");
        System.out.print("deldir-------删除给定路径的空目录，若不为空则提醒。\n");
        System.out.print("             该命令需要1个或2个参数。\n");
        System.out.print("xcopydir-----给定某个目录名，将它连同其子子孙孙复制到给定的路径下。\n");
        System.out.print("             该命令需要2个参数。\n");
        System.out.print("cd-----------切换给定路径为当前目录。\n");
        System.out.print("             该命令需要1个参数。\n");
        System.out.print("create-------创建指定路径下给定文件名的文件。\n");
        System.out.print("             该命令需要1个或2个参数。\n");
        System.out.print("open---------打开指定路径下的指定文件。\n");
        System.out.print("             该命令需要1个或2个参数。\n");
        System.out.print("close--------关闭已打开的文件。\n");
        System.out.print("             该命令需要0个参数。\n");
        System.out.print("read---------读指定路径下给定文件名的文件。\n");
        System.out.print("             该命令需要0个参数。\n");
        System.out.print("write--------写指定路径下给定文件名的文件。\n");
        System.out.print("             该命令需要0个参数。\n");;
        System.out.print("copy---------将给定文件名的文件复制到给定路径下。\n");
        System.out.print("             该命令需要2个参数。\n");
        System.out.print("exit---------退出本系统。\n");
    }

    public static void cd(String path) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag3 = true;

        for(int i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    System.out.println("成功切换至"+showpath.name);
                    break;
                }
            }

            if (!flag2) {
                flag3 = false;
                break;
            }
        }

       
    }
    public static void dir(String path) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag = true;

        int i;
        for(i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag = false;
                break;
            }
        }

        if (!flag) {
            System.out.println("路径错误！");

        } else {
            System.out.print("目录文件：\n");

            for(i = 0; i < showpath.sonnum; ++i) {
                Catalog var10001 = showpath.son[i];
                System.out.print(var10001.name + "\n");
            }

            System.out.print("\n\n文件信息：\n文件名          起始地址          大小          最近修改时间\n");

            for(i = 0; i < showpath.inodenum; ++i) {
                String var8 = showpath.inode[i].name;
                System.out.print(var8 + "          " + showpath.inode[i].address + "          " + showpath.inode[i].size + "          " + showpath.inode[i].lastime + "\n");
            }


        }
    }

    public static void treedir() {
        StringBuffer context = new StringBuffer();
        System.out.print(Main.nowcpoint.name + "\n");
        Treedir(Main.nowcpoint, 0, context);
       

    }

    public static void treedir(String path) {
        StringBuffer context = new StringBuffer();
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag = true;

        for(int i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag = false;
                break;
            }
        }

        if (!flag) {
           System.out.println("路径错误！");

        } else {
            System.out.print(showpath.name + "\n");
            Treedir(showpath, 0, context);
          

        }
    }

    public static void Treedir(Catalog dir, int level, StringBuffer context) {
        int i;
        int j;
        for(i = 0; i < dir.sonnum; ++i) {
            for(j = 0; j < level; ++j) {
                System.out.print("┃     ");
            }

            Catalog var10001 = dir.son[i];
            System.out.print("┃--- " + var10001.name + "\n");
            Treedir(dir.son[i], level + 1, context);
        }

        for(i = 0; i < dir.inodenum; ++i) {
            for(j = 0; j < level; ++j) {
                System.out.print("┃     ");
            }

            FCB var5 = dir.inode[i];
            System.out.print("┃--- " + var5.name + "\n");
        }

    }

    public static void mkdir(String name) {
        for(int i = 0; i < Main.nowcpoint.sonnum; ++i) {
            if (Main.nowcpoint.son[i].name.equals(name)) {
               System.out.println("该文件夹已存在！");

                return;
            }
        }

        Catalog newdir = new Catalog();
        newdir.name = name;
        newdir.sonnum = 0;
        newdir.inodenum = 0;
        Main.nowcpoint.son[Main.nowcpoint.sonnum] = newdir;
        ++Main.nowcpoint.sonnum;

        try {
            Main.write();
        } catch (IOException var3) {
            var3.printStackTrace();
        }

       System.out.println("文件夹创建成功！");

    }

    public static void mkdir(String path, String name) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag = true;

        int i;
        for(i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag = false;
                break;
            }
        }

        if (!flag) {
          System.out.println("路径错误！");

        } else {
            for(i = 0; i < showpath.sonnum; ++i) {
                if (showpath.son[i].name.equals(name)) {
                   System.out.println("该文件夹已存在！");

                    return;
                }
            }

            Catalog newdir = new Catalog();
            newdir.name = name;
            newdir.sonnum = 0;
            newdir.inodenum = 0;
            showpath.son[showpath.sonnum] = newdir;
            ++showpath.sonnum;

            try {
                Main.write();
            } catch (IOException var8) {
                var8.printStackTrace();
            }

           System.out.println("文件夹创建成功！");

        }
    }

    public static void deldir(String name) {
        Catalog target = null;
        int index = -1;
        boolean flag = false;

        int i;
        for(i = 0; i < Main.nowcpoint.sonnum; ++i) {
            if (Main.nowcpoint.son[i].name.equals(name)) {
                flag = true;
                target = Main.nowcpoint.son[i];
                index = i;
                break;
            }
        }

        if (!flag) {
            System.out.println("目标文件夹不存在！");
        } else {
            if (target.sonnum == 0 && target.inodenum == 0) {
                for(i = index; i < Main.nowcpoint.sonnum - 1; ++i) {
                    Main.nowcpoint.son[i] = Main.nowcpoint.son[i + 1];
                }

                --Main.nowcpoint.sonnum;
               System.out.println("目标文件夹删除成功！");

                try {
                    Main.write();
                } catch (IOException var5) {
                    var5.printStackTrace();
                }
            } else {
              System.out.println("该文件夹不为空，请确认是否删除（yes/no）：");
                deleteconfirm = target;
            }

        }
    }

    public static void deldir(String path, String name) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag = true;

        for(int i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag = false;
                break;
            }
        }

        if (!flag) {
           System.out.println("路径错误！");

        } else {
            Catalog target = null;
            int index = -1;
            boolean flag2 = false;

            int i;
            for(i = 0; i < showpath.sonnum; ++i) {
                if (showpath.son[i].name.equals(name)) {
                    flag2 = true;
                    target = showpath.son[i];
                    index = i;
                    break;
                }
            }

            if (!flag2) {
                System.out.println("目标文件夹不存在！");

            } else {
                if (target.sonnum == 0 && target.inodenum == 0) {
                    for(i = index; i < showpath.sonnum - 1; ++i) {
                        showpath.son[i] = showpath.son[i + 1];
                    }

                    --showpath.sonnum;
                    System.out.println("目标文件夹删除成功！");

                    try {
                        Main.write();
                    } catch (IOException var9) {
                        var9.printStackTrace();
                    }
                } else {
                    System.out.println("该文件夹不为空，请确认是否删除（yes/no）：");
                    deleteconfirm = target;
                    deleteconfirm2 = path;
                }

            }
        }
    }

    public static void deldir() {
        int index = -1;

        int i;
        for(i = 0; i < Main.nowcpoint.sonnum; ++i) {
            if (Main.nowcpoint.son[i].name.equals(deleteconfirm.name)) {
                index = i;
                break;
            }
        }

        for(i = index; i < Main.nowcpoint.sonnum - 1; ++i) {
            Main.nowcpoint.son[i] = Main.nowcpoint.son[i + 1];
        }

        --Main.nowcpoint.sonnum;
        System.out.println("目标文件夹删除成功！");

        try {
            Main.write();
        } catch (IOException var2) {
            var2.printStackTrace();
        }

    }


     public static void xcopydir2(Catalog target, Catalog showpath) {
        int i;
        for(i = 0; i < target.sonnum; ++i) {
            Catalog newdir = new Catalog();
            newdir.sonnum = 0;
            newdir.inodenum = 0;
            newdir.name = target.son[i].name;
            showpath.son[showpath.sonnum] = newdir;
            ++showpath.sonnum;
            xcopydir2(target.son[i], newdir);
        }

        for(i = 0; i < target.inodenum; ++i) {
            FCB newfile = new FCB();
            newfile.name = target.inode[i].name;
            newfile.size = target.inode[i].size;
            newfile.address = Main.total.freetable.address;
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd-hh:mm:ss");
            newfile.lastime = dateFormat.format(date);
            showpath.inode[showpath.inodenum] = newfile;
            ++showpath.inodenum;
            Main.total.freetable.address += newfile.size;
            Main.total.freetable.length -= newfile.size;
        }

    }
    public static void xcopydir(String path, String name) {
        Catalog target = null;
        boolean flag = false;
        for(int i = 0; i < Main.nowcpoint.sonnum; ++i) {
            if (Main.nowcpoint.son[i].name.equals(name)) {
                flag = true;
                target = Main.nowcpoint.son[i];
                break;
            }
        }

        if (!flag) {
            System.out.println("目标文件夹不存在！");

        } else {
            Catalog showpath = Main.total.boot;
            String[] str = path.split("/");
            boolean flag3 = true;

            for(int i = 0; i < str.length; ++i) {
                boolean flag2 = false;

                for(int j = 0; j < showpath.sonnum; ++j) {
                    if (showpath.son[j].name.equals(str[i])) {
                        flag2 = true;
                        showpath = showpath.son[j];
                        break;
                    }
                }

                if (!flag2) {
                    flag3 = false;
                    break;
                }
            }

            if (!flag3) {
                System.out.println("路径错误！");

            } else {
                Catalog newdir = new Catalog();
                newdir.name = target.name;
                newdir.sonnum = 0;
                newdir.inodenum = 0;
                showpath.son[showpath.sonnum] = newdir;
                ++showpath.sonnum;
                xcopydir2(target, newdir);
               System.out.println("文件夹复制成功！");

                try {
                    Main.write();
                } catch (IOException var11) {
                    var11.printStackTrace();
                }

            }
        }
    }

    


    public static void create(String path, String name) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag3 = true;

        int i;
        for(i = 0; i < str.length; ++i) {
            boolean flag2 = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag3 = false;
                break;
            }
        }

        if (!flag3) {
          System.out.println("路径错误！");

        } else {
            for(i = 0; i < showpath.inodenum; ++i) {
                if (showpath.inode[i].name.equals(name)) {
                   System.out.println("该目录下已存在同名文件！");

                    return;
                }
            }

            FCB newfile = new FCB();
            newfile.name = name;
            newfile.size = 0;
            newfile.address = Main.total.freetable.address;
            newfile.text=null;
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd-hh:mm:ss");
            newfile.lastime = dateFormat.format(date);
            showpath.inode[showpath.inodenum] = newfile;
            ++showpath.inodenum;
            System.out.println("目标文件创建成功！");

            try {
                Main.write();
            } catch (IOException var9) {
                var9.printStackTrace();
            }

        }
    }



    public static void open(String path, String name) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag3 = true;

        int i;
        for( i = 0; i < str.length; ++i) {
            boolean flag2 = false;
            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag2 = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag2) {
                flag3 = false;
                break;
            }
        }

        if (!flag3) {
            System.out.println("路径错误！");

        } else {
            boolean flag5 = false;
            FCB target = null;
            for(i = 0; i < showpath.inodenum; ++i) {
                if (showpath.inode[i].name.equals(name)) {
                    flag5 = true;
                    target = showpath.inode[i];
                    break;
                }
            }

            if (!flag5) {
               System.out.println("目标文件不存在！");

            } else {
                Main.openfile = target;
               System.out.println("目标文件已打开！");

            }
        }
    }

    public static void close() {
        if (Main.openfile == null) {
            System.out.println("当前没有被打开的文件！");

        } else {
            Main.openfile = null;
           System.out.println("文件已关闭！");

        }
    }

    public static void read() {
        if (Main.openfile == null) {
           System.out.println("当前没有被打开的文件！");

        } else {
           System.out.println("文件内容如下：\n" +"name: "+Main.openfile.name +"  text: "+ Main.openfile.text +"  size: "+Main.openfile.size+"  lasttime: "+Main.openfile.lastime);
        }
    }

    public static void write() {
        Scanner scanner = new Scanner(System.in);
        if (Main.openfile == null) {
           System.out.println("当前没有被打开的文件！");

        } else {
            System.out.println("文件内容如下：" );
            Main.openfile.text=scanner.nextLine();
            Main.openfile.size = Main.openfile.text.length();
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd-hh:mm:ss");
            Main.openfile.lastime = dateFormat.format(date);
           try {
                Main.write();
            } catch (IOException var9) {
                var9.printStackTrace();
            }
        }
    }

    public static void deviation(int size, Catalog g) {
        int i;
        for(i = 0; i < g.inodenum; ++i) {
            if (g.inode[i].address >= Main.openfile.address && !g.inode[i].name.equals(Main.openfile.name)) {
                g.inode[i].address += size;
            }
        }

        for(i = 0; i < g.sonnum; ++i) {
            deviation(size, g.son[i]);
        }

    }

    public static void copy(String path, String name) {
        Catalog showpath = Main.total.boot;
        String[] str = path.split("/");
        boolean flag3 = true;

        boolean flag;
        int i;
        for(i = 0; i < str.length; ++i) {
            flag = false;

            for(int j = 0; j < showpath.sonnum; ++j) {
                if (showpath.son[j].name.equals(str[i])) {
                    flag = true;
                    showpath = showpath.son[j];
                    break;
                }
            }

            if (!flag) {
                flag3 = false;
                break;
            }
        }

        if (!flag3) {
            System.out.println("路径错误！");

        } else {
            FCB target = null;
            flag = false;

            for(i = 0; i < Main.nowcpoint.inodenum; ++i) {
                if (Main.nowcpoint.inode[i].name.equals(name)) {
                    flag = true;
                    target = Main.nowcpoint.inode[i];
                    break;
                }
            }

            if (!flag) {
               System.out.println("目标文件不存在！");

            } else {
                FCB newfile = new FCB();
                newfile.name = target.name;
                newfile.size = target.size;
                newfile.address = Main.total.freetable.address;
                Date date = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd-hh:mm:ss");
                newfile.lastime = dateFormat.format(date);
                showpath.inode[showpath.inodenum] = newfile;
                ++showpath.inodenum;
                Main.total.freetable.address += target.size;
                Main.total.freetable.length -= target.size;
                System.out.println("文件复制成功！");

                try {
                    Main.write();
                } catch (IOException var11) {
                    var11.printStackTrace();
                }

            }
        }
    }
}

 