package manage;
public class FCB {
    public String name;//文件名
    public String lastime;//最近一次修改时间
    public String text;//内容
    public int size;//大小
    public int address;//起始地址
}