package manage;
public class Total {
    public freeTable freetable = new freeTable();
    public int fileNumber;
    public char[] buffer;
    public Catalog boot;

    public Total() {
        this.freetable.address = 0;
        this.freetable.length = 67108864;
        this.fileNumber = 0;
        this.buffer = new char[67108864];
        this.boot = new Catalog();
        this.boot.sonnum = 0;
        this.boot.inodenum = 0;
        this.boot.name = "/";
        Catalog A = new Catalog();
        A.sonnum = 0;
        A.inodenum = 0;
        A.name = "A";
        InitDisk(A, 33554432);
        this.boot.son[this.boot.sonnum] = A;
        ++this.boot.sonnum;
        Catalog B = new Catalog();
        B.sonnum = 0;
        B.inodenum = 0;
        B.name = "B";
        InitDisk(B, 33554432);
        this.boot.son[this.boot.sonnum] = B;
        ++this.boot.sonnum;
    }
    void InitDisk(Catalog x,int a){//初始化磁盘
        if(this.freetable.length<a)
        {
            System.out.println("磁盘空间不足");
            return;
        }
        else
        {
           x.freetable.address=a;
           this.freetable.length-=a; 
           x.size=a;
        }
    }
}