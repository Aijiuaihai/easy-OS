import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JOptionPane;


public class Server {
    boolean isRunning = true;
    // TODO 以下是存放数据的变量
    public static int localPort = 63814; // 默认端口 
    public static String localIP = "127.0.0.1"; // 默认ip地址
    static int SerialNum = 0; // 用户连接数量
    ServerSocket serverSocket; // 服务器端 Socket
    ArrayList<AcceptRunnable.Client> clients = new ArrayList<>(); // 用户连接对象数组
    Vector<String> clientNames = new Vector<>(); // lstUsers 中存放的数据

    // TODO 构造方法
    public boolean checkUsernameExists(String username) {
        return clientNames.contains(username);
    }
    public Server() {
        
        try {      
            // 创建服务器端 Socket 并启动新进程、监听端口
            serverSocket = new ServerSocket(localPort);
            Thread acptThrd = new Thread(new AcceptRunnable());
            acptThrd.start();
            System.out.println("**** 服务器（端口" + localPort + "）已启动 ****\n");

            // 创建一个 Scanner 对象来读取控制台输入
            Scanner scanner = new Scanner(System.in);
            // 打印一些指令和选项给用户
            System.out.println("-欢迎使用聊天服务器！-");
            System.out.println("-您可以使用以下命令来管理聊天室：");
            System.out.println("- end - 关闭服务器");
            System.out.println("- count - 显示当前在线用户数量");
            System.out.println("- chatUser - 显示当前在线用户列表");
            System.out.println("- kickout + 空格 + 昵称 - 踢出指定用户");
            while (true) {
                String input = scanner.nextLine(); // 读取一行输入
                // 如果输入是 end，则关闭服务器 并 告知所有用户当前信息，跳出循环终止当前进程
                if (input.equals("end")) {
                    for (AcceptRunnable.Client c : clients) {
                        c.out.println("——各位，聊天就此结束，谢谢大家\n");
                        c.socket.close();
                    }
                    System.out.println("——服务器关闭\n");
                    serverSocket.close();
                    isRunning = false;
                    break;
                }
                // 如果输入是 count，则显示当前在线用户数量
                if (input.equals("count")) {
                    System.out.println("——当前在线用户数量：" + clients.size() + "\n");
                }
                // 如果输入是 chatUser，则显示当前在线用户列表
                if (input.equals("chatUser")) {
                    System.out.println("——当前在线用户：" + clientNames.toString() + "\n");
                }
                // 如果输入是 kickout + 空格 + 昵称，则踢出指定用户 并 告知所有用户当前信息
                if (input.startsWith("kickout ")) {
                    String nickname = input.substring(8); // 获取昵称
                    for (AcceptRunnable.Client c : clients) {
                        if (c.nickname.equals(nickname)) { // 找到匹配的用户
                            c.out.println("——你已被踢出\n");
                            c.socket.close();
                            clients.remove(c);
                            for (AcceptRunnable.Client d : clients) { // 告知其他用户
                                d.out.println("——用户【" + nickname + "】被踢出\n");
                            }
                            System.out.println("——用户【" + nickname + "】被踢出\n");
                            c.updateUsers(); // 更新在线用户列表
                            break;
                        }
                    }
                }
                // 再次打印一些指令和选项给用户
                System.out.println("\n您可以继续输入以下命令来管理聊天室：");
                System.out.println("end - 关闭服务器");
                System.out.println("count - 显示当前在线用户数量");
                System.out.println("chatUser - 显示当前在线用户列表");
                System.out.println("kickout + 昵称 - 踢出指定用户");
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    // TODO 接受用户连接请求的线程关联类
    private class AcceptRunnable implements Runnable {
        public void run() {
            // 持续监听端口，当有新用户连接时 再开启新进程
            while (isRunning) {
                try {
                    Socket socket = serverSocket.accept();
                    // 新的用户已连接，创建 Client 对象
                    Client client = new Client(socket);
                    System.out.println("——用户【" + client.nickname + "】加入\n");
                    Thread clientThread = new Thread(client);
                    clientThread.start();
                    clients.add(client);
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        }
        
        // TODO 服务器存放用户对象的客户类（主要编程）。每当有新的用户连接时，该类都会被调用
        // TODO 该类继承自 Runnable，内部含有 run()方法
        private class Client implements Runnable {
            private Socket socket; // 用来保存用户的连接对象
            private BufferedReader in; // IO 流
            private PrintStream out;
            private String nickname; // 保存用户昵称
            private boolean hasValidNickname ;
            boolean validNickname ;
            // Client类的构建方法。当有 新用户 连接时会被调用
            public Client(Socket socket) throws Exception {
                this.socket = socket;
                InputStream is = socket.getInputStream();
                in = new BufferedReader(new InputStreamReader(is));
                OutputStream os = socket.getOutputStream();
                out = new PrintStream(os);
               String tname;
                while (!validNickname) {
                    tname = in.readLine();
                    if (!checkUsernameExists(tname)) {
                        validNickname = true;
                        hasValidNickname = true;
                        nickname=tname;
                   
                    } else {
                        JOptionPane.showMessageDialog(null, "用户名已存在，请输入一个新的用户名：");
                        hasValidNickname = false;
                        validNickname = false;
                    }
                }
                for (Client c : clients) { // 将新用户的登录消息发给所有用户
                    c.out.println("——用户【" + nickname + "】加入\n");
                }
            }

            //客户类线程运行方法
            public void run() {
                try {
                    while (true) {
                        String usermsg = in.readLine(); //读用户发来消息
                        
                        // 如果用户发过来的消息不为空
                        if (usermsg != null && usermsg.length() > 0&& hasValidNickname) {
                            String secondMsg = usermsg.substring(usermsg.lastIndexOf(":") + 1); // 字符串辅助对象

                            // 如果消息是 bye，则断开与此用户的连接 并 告知所有用户当前信息，跳出循环终止当前进程
                            if (secondMsg.equals("bye")) {
                                clients.remove(this);
                                for (Client c : clients) {
                                    c.out.println(usermsg);
                                }
                                System.out.println("——用户离开：" + nickname + "\n");
                                // 更新在线用户数量 lstUsers的界面信息
                                updateUsers();
                                break;
                            }

                            /**
                             * 每当有新用户连接时，服务器就会接收到 USERS 请求 当服务器接收到此请求时，就会要求现在所有用户更新 在线用户数量 的列表 */
                            if (usermsg.equals("USERS")) {
                                updateUsers();
                                continue;
                            }
                            // 当用户发出的消息都不是以上两者时，消息才会被正常发送                  
                                for (Client c : clients) {
                                 c.out.println(usermsg);
                             }
                             System.out.println(usermsg);
                        }
                    }
                    socket.close();
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }

            // TODO 更新在线用户数量 lstUsers 信息，并要求所有的用户端同步更新
            public void updateUsers() {
                // clientNames 是 Vector<String>对象，用来存放所有用户的名字
                clientNames.removeAllElements();
                StringBuffer allname = new StringBuffer();
                for (AcceptRunnable.Client client : clients) {
                    clientNames.add(0, client.nickname);
                    allname.insert(0, "|" + client.nickname);
                }
                System.out.println("在线用户(" + clientNames.size() + "个):" + allname.toString());
                // 要求所有的用户端同步更新
                for (Client c : clients) {
                    c.out.println(clientNames);
                }
            }
        }
    }

    public static void main(String[] args) {
        new Server();
    }
}


